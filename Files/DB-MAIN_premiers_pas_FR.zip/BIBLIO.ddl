-- *********************************************
-- * Standard SQL generation                   
-- *--------------------------------------------
-- * DB-MAIN version: 11.0.2              
-- * Generator date: Sep 14 2021              
-- * Generation date: Tue Jul 19 13:09:27 2022 
-- * LUN file: D:\-jlh-\DOCUMENT\TUTORIAL\1er-Pas\Biblio.lun 
-- * Schema: Biblio/Physique 
-- ********************************************* 


-- Database Section
-- ________________ 

create database Biblio;


-- DBSpace Section
-- _______________

create dbspace PRETS.file;

create dbspace FONDS.file;


-- Tables Section
-- _____________ 

create table AUTEUR (
     ISBN char(14) not null,
     NOM_AUTEUR char(24) not null,
     constraint IDAUTEUR_ID primary key (ISBN, NOM_AUTEUR));

create table EMPRUNTEUR (
     NOM char(64) not null,
     ADRESSE char(128),
     constraint IDEMPRUNTEUR_ID primary key (NOM));

create table EXEMPLAIRE (
     ISBN char(14) not null,
     NUMERO_SERIE numeric(8) not null,
     LOC_TRAVEE char(4) not null,
     LOC_ETAGERE numeric(2) not null,
     LOC_TABLETTE numeric(2) not null,
     EMPRUNTEUR char(64),
     constraint IDEXEMPLAIRE_ID primary key (ISBN, NUMERO_SERIE));

comment on table EXEMPLAIRE is 'Un exemplaire est un livre ';
comment on column EXEMPLAIRE.NUMERO_SERIE is 'Lors de l''achat d''un exemplaire d''un ouvrage, le bibliothéquaire lui assigne le numéro suivant parmi les exemplaires de cet ouvrage déjà enregistrés. Le numéro d''un exemplaire retiré n''est pas réutilisé.';

create table OUVRAGE (
     ISBN char(14) not null,
     TITRE char(64) not null,
     constraint IDOUVRAGE_ID primary key (ISBN));


-- Constraints Section
-- ___________________ 

alter table AUTEUR add constraint FKECRIT_PAR
     foreign key (ISBN)
     references OUVRAGE;

alter table EXEMPLAIRE add constraint FKDE
     foreign key (ISBN)
     references OUVRAGE;

alter table EXEMPLAIRE add constraint FKEMPRUNTE_FK
     foreign key (EMPRUNTEUR)
     references EMPRUNTEUR;


-- Index Section
-- _____________ 

create unique index IDAUTEUR_IND
     on AUTEUR (ISBN, NOM_AUTEUR);

create unique index IDEMPRUNTEUR_IND
     on EMPRUNTEUR (NOM);

create unique index IDEXEMPLAIRE_IND
     on EXEMPLAIRE (ISBN, NUMERO_SERIE);

create index FKEMPRUNTE_IND
     on EXEMPLAIRE (EMPRUNTEUR);

create unique index IDOUVRAGE_IND
     on OUVRAGE (ISBN);

