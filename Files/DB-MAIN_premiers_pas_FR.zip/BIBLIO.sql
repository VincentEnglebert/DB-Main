-- *********************************************
-- * SQL SQLite generation                     
-- *--------------------------------------------
-- * DB-MAIN version: 11.0.2              
-- * Generator date: Sep 14 2021              
-- * Generation date: Tue Jul 19 12:04:35 2022 
-- * LUN file: D:\-jlh-\DOCUMENT\TUTORIAL\1er-Pas\Biblio.lun 
-- * Schema: Biblio/Physique 
-- ********************************************* 


-- Database Section
-- ________________ 


-- Tables Section
-- _____________ 

create table AUTEUR (
     ISBN char(14) not null,
     NOM_AUTEUR char(24) not null,
     constraint IDAUTEUR primary key (ISBN, NOM_AUTEUR),
     foreign key (ISBN) references OUVRAGE);

create table EMPRUNTEUR (
     NOM char(64) not null,
     ADRESSE char(128),
     constraint IDEMPRUNTEUR primary key (NOM));

create table EXEMPLAIRE (
     ISBN char(14) not null,
     NUMERO_SERIE numeric(8) not null,
     LOC_TRAVEE char(4) not null,
     LOC_ETAGERE numeric(2) not null,
     LOC_TABLETTE numeric(2) not null,
     EMPRUNTEUR char(64),
     constraint IDEXEMPLAIRE primary key (ISBN, NUMERO_SERIE),
     foreign key (ISBN) references OUVRAGE,
     foreign key (EMPRUNTEUR) references EMPRUNTEUR);

--comment on table EXEMPLAIRE is 'Un exemplaire est un livre ';
--comment on column EXEMPLAIRE.NUMERO_SERIE is 'Lors de l''achat d''un exemplaire d''un ouvrage, le bibliothéquaire lui assigne le numéro suivant parmi les exemplaires de cet ouvrage déjà enregistrés. Le numéro d''un exemplaire retiré n''est pas réutilisé.';

create table OUVRAGE (
     ISBN char(14) not null,
     TITRE char(64) not null,
     constraint IDOUVRAGE primary key (ISBN));


-- Index Section
-- _____________ 

create unique index IDAUTEUR
     on AUTEUR (ISBN, NOM_AUTEUR);

create unique index IDEMPRUNTEUR
     on EMPRUNTEUR (NOM);

create unique index IDEXEMPLAIRE
     on EXEMPLAIRE (ISBN, NUMERO_SERIE);

create index FKemprunté
     on EXEMPLAIRE (EMPRUNTEUR);

create unique index IDOUVRAGE
     on OUVRAGE (ISBN);

